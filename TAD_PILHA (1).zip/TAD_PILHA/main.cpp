#include <stdio.h>
#include <stdlib.h>
#include "Pilha.h"
#define N 4


int main ()
{
    TipoPilha *pilha1, *pilha2;
    TipoInfo Dado;
    int i,j;

    pilha1=InicializaPilha();
    pilha2=InicializaPilha();

    for(j=0;j<2;j++){
        printf("Preencha a Lista 1:\n");
        for(i=0;i<N;i++){
            printf("%d) ", i+1);
            scanf(" %d", &Dado);
            pilha1=PushPilha(pilha1, Dado);
        }
        printf("\nPreencha a Lista 2:\n");
        for(i=0;i<N;i++){
            printf("%d) ", i+1);
            scanf(" %d", &Dado);
            pilha2=PushPilha(pilha2, Dado);
        }
        printf("\nImprimindo a lista 1:\n");
        printf("=======================\n");
        ImprimirPilha(pilha1);
        printf("=======================\n");
        printf("\nImprimindo a lista 2:\n");
        printf("=======================\n");
        ImprimirPilha(pilha2);
        printf("=======================\n");

        printf("\nComparando as listas:\n");
        printf("========================================\n");
        if(comparaPilha(pilha1, pilha2))
            printf("Lista 1 e lista 2 sao iguais!\n");
        else
            printf("Lista 1 e lista 2 nao sao iguais!\n");
        printf("========================================\n\n");
        pilha1=InicializaPilha();
        pilha2=InicializaPilha();
    }
    return 0;
}
